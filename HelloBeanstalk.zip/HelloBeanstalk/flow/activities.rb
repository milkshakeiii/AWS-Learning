# You can require your activity files here.
class HelloWorld
  def hello(input)
    "Hello #{input[:name]}"
  end
end
