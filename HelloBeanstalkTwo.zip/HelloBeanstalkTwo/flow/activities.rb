# You can require your activity files here.
class HelloWorld
  def hello(input)
    "Howdy #{input[:name]}!"
  end
end
